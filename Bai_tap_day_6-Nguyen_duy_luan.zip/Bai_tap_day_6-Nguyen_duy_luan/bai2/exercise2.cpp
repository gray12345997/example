#include<iostream>
#include<string>
#include<vector>
#include<algorithm>

using namespace std;

class name {
public:
	string ho, tenDem, ten;
	void input();
	void output();
};

void name::input() {
	cin.ignore();
	cout << "Nhap ho : " << endl;
	getline(cin, ho);
	cin.ignore();
	cout << "Nhap ten dem : "; getline(cin, tenDem);
	cin.ignore();
	cout << "Nhap ten : ";
	getline(cin, ten);
	cin.ignore();
}

void name::output() {
	cout << "\n Ho ten : " << ho << " " << tenDem << " " << ten;
}

class queQuan {
public :
	string xa, huyen, tinh;
	void input();
	void output();
};

void queQuan::input() {
	cout << "Nhap xa : ";
	getline(cin, xa);
	cin.ignore();
	cout << "Nhap huyen : ";
	getline(cin, huyen);
	cin.ignore();
	cout << "Nhap tinh : ";
	getline(cin, tinh);
	cin.ignore();
}

void queQuan::output() {
	cout << "\nQue Quan : " << xa << " " << huyen << " " << tinh;
}

class Diemthi {
public:
	float toan, ly, hoa;
	void input();
	void output();
};

void Diemthi::input() {
	cout << "Nhap diem toan : ";
	cin >> toan;
	cout << "Nhap diem ly : ";
	cin >> ly;
	cout << "Nhap diem hoa : ";
	cin >> hoa;
}

void Diemthi::output() {
	cout << "Toan : " << toan << endl;
	cout << "Ly : " << ly << endl;
	cout << "Hoa : " << hoa << endl;
}

class THISINH : public name, public queQuan, public Diemthi {
public :
	void input();
	void output();
	float tongDiem() {
		return toan + ly + hoa;
	}
};

void THISINH::input() {
	name::input();
	queQuan::input();
	Diemthi::input();
}

void THISINH::output() {
	name::output();
	queQuan::output();
	Diemthi::output();
}

int main() {
	int n;
	cout << "Nhap so thi sinh : ";
	cin >> n;

	THISINH ts;
	vector<THISINH> x;
	for (int i = 0; i < n; i++) {
		cout << "\n\t Nhap thong tin thi sinh : " << i + 1 << endl;
		ts.input();
		x.push_back(ts);
	}
	
	cout << "\n Output : ";
	int a = x.size();
	for (int i = 0; i < a; i++) {
		cout << "\n\t Thi sinh : " << i + 1 << endl;
		x[i].output();
	}

	cout << "\n Danh sach thi sinh co tong diem 3 mon lon hon 15 la : ";
	for (int i = 0; i < a; i++) {
		if (x[i].tongDiem() > 15) {
			cout << "\n\tThi sinh : " << i + 1 << endl;
			x[i].output();
		}
	}

	cout << "\n sap xep giam : " << endl;
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n - i - 1; j++) {
			THISINH temp;
			if (x[j].tongDiem() < x[j + 1].tongDiem()) {
				temp = x[j];
				x[j] = x[j + 1];
				x[j] = temp;
			}
		}
	}

	for (int i = 0; i < a; i++) {
		cout << "\n\t Thi sinh : " << i + 1 << endl;
		x[i].output();
	}


	return 0;
}