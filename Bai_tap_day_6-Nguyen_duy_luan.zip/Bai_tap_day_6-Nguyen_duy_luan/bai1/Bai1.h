#pragma once

#ifndef __DOG_H__
#define __DOG_H__
#include <string>
#include<iostream>
#include<iomanip>

using namespace std;

class CGoods {
    protected:
        char m_cCode[4]; // ma hang 
        char m_cName[20]; // ten hang 
        char m_cUnit[10]; // don vi tinh
        float m_fUPrice; //  thanh tien 
        float m_fValue; // don gia
        int m_nNumberOfGood; // so luong 

    public :
        void Input() {
            cout << "Nhap ma hang : " << endl;
            cin >> m_cCode;
            cout << "Nhap ten hang : " << endl;
            cin >> m_cName;
            cout << "Nhap don vi tinh :   " << endl;
            cin >> m_cUnit;
            cout << "Nhap don gia : " << endl;
            cin >> m_fValue;
            cout << "Nhap so luong : " << endl;
            cin >> m_nNumberOfGood;

        }
        void countMoney() {
            this->m_fUPrice = this->m_nNumberOfGood * this->m_fValue;
            
        }

        void display();
};

class newCGoods : public CGoods {
public :
    float m_fShippingUnitPrice;// don gia van chuyen 
    float m_fTransCost; // phi van chuyen 

public :
    void transportationCosts();
    void payment();
};

void CGoods::display() {
    cout << m_cCode << setw(20) << left << m_cName << setw(10) << left << m_cUnit << setw(10) << left << m_fValue << setw(10) << left << m_nNumberOfGood << setw(10) << right << m_fUPrice << endl;
}

void newCGoods::transportationCosts(){
    cout << "Nhap don gia van chuyen : " << endl; 
    cin >> m_fShippingUnitPrice;
    this->m_fTransCost =  m_fShippingUnitPrice * m_nNumberOfGood;
    cout << m_fTransCost << endl;
}

void newCGoods::payment() {
    cout << (m_fUPrice + m_fTransCost) << endl;
}


#endif

