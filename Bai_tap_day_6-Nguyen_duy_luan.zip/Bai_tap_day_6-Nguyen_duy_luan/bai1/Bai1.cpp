#include<iostream>
#include "Bai1.h"

int main() {
	newCGoods d;
	d.Input();
	d.countMoney();
	d.display();
	d.transportationCosts();
	d.payment();



}