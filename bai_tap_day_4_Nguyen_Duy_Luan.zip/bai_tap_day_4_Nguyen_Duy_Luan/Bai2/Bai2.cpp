#include<iostream>
#include<iomanip>

using namespace std;

int GiaiThua(int n ){
    int gt = 1;
    if(n == 0 || n == 1){
        return 1; 
    }else{
        for(int i = n ; i >= 1 ;i-- ){
        gt*= i;
        }
    }

    return gt ;
}

int main(){

    int n = -1 ;
    while(n <0){
        cout <<"Nhap n : " ;
        cin >> n;
    }
  
    //cin.ignore();

    cout << n << " giai thua la : " << GiaiThua(n) << endl;




    return 0;
}