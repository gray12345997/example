#include<iostream>

using namespace std;

void medium( int &n ){
    int sum = 0 ;
    cin >> n ;
    int *arr = new int [n];

    for(int i = 0 ;i < n ;i++){
        cin >> arr[i];
        sum += arr[i];
    }

    sum = (float) sum / n ;
    cout << "Trung binh la : "  << endl;
    cout << sum << endl;

    delete [] arr ;
}

int main(){
    int n ;

    medium(n);

    return 0;
}