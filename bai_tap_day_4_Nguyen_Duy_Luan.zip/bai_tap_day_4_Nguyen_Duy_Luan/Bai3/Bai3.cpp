#include<iostream>
#include<math.h>

using namespace std;


void area(double r){
    cout <<"Dien tich hinh tron la : " << endl  ;

    cout << 3.14 * r * r << endl;
}

double area(double a , double b ){
    cout << "Dien tich hinh chu nhat la : " << endl ;
    
    cout << a * b  << endl;
}

void area(float a , float b , float c ){
    cout << "Dien tich hinh tam giac la : " << endl ;
    
    float p = (float)(a + b + c )/2;
    float s = sqrt(p * (p - 1 ) * (p - b )*(p -c ));
    cout << s << endl;
}

int main(){
    area(5);

    area(4, 8 , 7);

    area(4,5);

    return 0;
}